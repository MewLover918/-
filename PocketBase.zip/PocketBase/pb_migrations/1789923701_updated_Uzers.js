/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3679016392")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE UNIQUE INDEX `idx_tokenKey_7vr22gqolu` ON `User` (`tokenKey`)",
      "CREATE UNIQUE INDEX `idx_email_7vr22gqolu` ON `User` (`email`) WHERE `email` != ''"
    ],
    "name": "User"
  }, collection)

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3679016392")

  // update collection data
  unmarshal({
    "indexes": [
      "CREATE UNIQUE INDEX `idx_tokenKey_7vr22gqolu` ON `Uzers` (`tokenKey`)",
      "CREATE UNIQUE INDEX `idx_email_7vr22gqolu` ON `Uzers` (`email`) WHERE `email` != ''"
    ],
    "name": "Uzers"
  }, collection)

  return app.save(collection)
})
